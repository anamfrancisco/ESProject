/*
 * Created on 21.11.2004
 */
package net.sourceforge.ganttproject.chart.item;

import net.sourceforge.ganttproject.task.Task;

/**
 * @author bard
 */
public class TaskRegularAreaChartItem extends ChartItem {

  public TaskRegularAreaChartItem(Task task) {
    super(task);
    // TODO Auto-generated constructor stub
  }

}
