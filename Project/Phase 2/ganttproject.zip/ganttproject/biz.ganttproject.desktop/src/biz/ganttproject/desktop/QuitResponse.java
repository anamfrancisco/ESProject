// Copyright (C) 2018 BarD Software
package biz.ganttproject.desktop;

/**
 * @author dbarashev@bardsoftware.com
 */
public interface QuitResponse {
  void performQuit();
  void cancelQuit();
}
